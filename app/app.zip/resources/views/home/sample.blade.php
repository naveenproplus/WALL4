@extends('home.home-render-layout')
@section('content')
{{$Content}}
@endsection

@section('scripts')

@endsection

